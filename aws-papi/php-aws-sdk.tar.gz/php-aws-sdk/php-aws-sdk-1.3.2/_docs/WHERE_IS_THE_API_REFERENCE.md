You can find the API Reference at:
http://docs.amazonwebservices.com/AWSSDKforPHP/latest/
